#!/usr/bin/env bash
# Install Patch, the Omarchy audio environment, for this user.
#
#   ./install.sh                     the Patch setup screen, then install
#   ./install.sh --profile minimal   no screen: full | minimal
#   ./install.sh --modules dj,ai_dj  no screen: the core and these modules
#                                    (dj ai_dj visualiser podcast live_coding plugins controllers themes)
#   ./install.sh --layout basic-dj   the default layout: simple basic-dj ai-dj
#                                    performance-dj dj-studio podcast live-code pro
#   ./install.sh --no-stems          don't download the stem separator (AI DJ)
#   ./install.sh --no-remote         don't set up the phone remote (Tailscale)
#   ./install.sh --no-deps           skip installing Arch packages
#   ./install.sh --no-bar            leave the bar's audio menu as it is
#   ./install.sh --no-service        don't start Patch with the session
#   ./install.sh --build             compile here, even with a ready-made build
#   PREFIX=/usr/local ./install.sh   another prefix (needs write access)
#
# What it does: asks how you want to use Patch (Minimal: the core only,
# Patch replacing Omarchy's audio; Full; or Custom: the core and the
# modules you pick) and which layout the Patch launcher opens,
# installs the Arch packages it needs (pacman), takes this release's
# ready-made binary for your machine (x86-64 or ARM64; compiled here only
# when there is none, which takes minutes), installs it with its
# launchers and themes, applies your setup and shows a short guide. At
# login only Patch's audio service starts; no window opens by itself.
# Change any of it later in the controller (Ctrl+K, Setup) or with
# `omarchy-patch setup`. ./uninstall.sh undoes it.
set -euo pipefail

cd "$(dirname "$0")"
PREFIX="${PREFIX:-$HOME/.local}"
BIN="$PREFIX/bin"
APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
SHARE="$PREFIX/share/omarchy-patch"
# A source checkout has Cargo.toml; a binary kit has only its VERSION.
if [[ -f Cargo.toml ]]; then
  VERSION=$(sed -n 's/^version = "\(.*\)"/\1/p' Cargo.toml | head -1)
else
  VERSION=$(cat VERSION)
fi
REPO=novuon/Patch
ARCH=$(uname -m)
DEPS=1
BUILD_HERE=0
PROFILE=""
MODULES_ARG=""
LAYOUT=""
STEMS=1
REMOTE=1
OVERRIDES=()
while (($#)); do
  case "$1" in
    --no-deps) DEPS=0 ;;
    --no-bar) OVERRIDES+=(bar=off) ;;
    --no-service) OVERRIDES+=(start_with_session=off) ;;
    --build) BUILD_HERE=1 ;;
    --profile) PROFILE="${2:-}"; shift ;;
    --profile=*) PROFILE="${1#*=}" ;;
    --modules) MODULES_ARG="${2:-}"; PROFILE=custom; shift ;;
    --modules=*) MODULES_ARG="${1#*=}"; PROFILE=custom ;;
    --layout) LAYOUT="${2:-}"; shift ;;
    --layout=*) LAYOUT="${1#*=}" ;;
    --no-stems) STEMS=0 ;;
    --no-remote) REMOTE=0 ;;
    -h|--help) sed -n '2,27p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

say() { printf '\033[1m» %s\033[0m\n' "$*"; }

# Patch places its windows with Hyprland's Lua API (0.56+). On an older
# Hyprland the layouts don't work: windows land anywhere and the pointer
# jumps to each new one. Audio itself works; the windows don't behave.
HYPR_MIN=0.56
# No Hyprland to ask (an SSH or TTY install): no check, and no exit
# (set -e and pipefail would end the installer here without a word).
hypr=$(hyprctl version -j 2>/dev/null | sed -n 's/.*"version": *"\([0-9.]*\)".*/\1/p' | head -1) || hypr=""
if [[ -n $hypr && $(printf '%s\n' "$HYPR_MIN" "$hypr" | sort -V | head -1) != "$HYPR_MIN" ]]; then
  printf '\033[1;33m» Hyprland %s found: Patch needs %s or newer.\033[0m\n' "$hypr" "$HYPR_MIN" >&2
  echo "  Its windows won't arrange (they land anywhere, the pointer jumps to each)." >&2
  echo "  Update Omarchy first (omarchy-update), then run ./install.sh again." >&2
  if [[ -t 0 && -t 1 ]] && command -v gum >/dev/null; then
    gum confirm "Install anyway?" --default=false || exit 1
  fi
fi

# ── The Patch setup screen ─────────────────────────────────────────────
# The core (always): Patch replaces Omarchy's audio — system audio, the
# service from login, the bar's audio menu and the audio Units. The
# modules and the themes, as `omarchy-patch setup` knows them.
CORE=(system_audio start_with_session bar)
MODULE_IDS=(dj ai_dj visualiser podcast live_coding plugins controllers themes)
declare -A MODULE_NAME=(
  [dj]="DJ" [ai_dj]="AI DJ & stems" [visualiser]="Visualiser" [podcast]="Podcast & broadcast"
  [live_coding]="Live coding" [plugins]="Plugins" [controllers]="Controllers" [themes]="Themes"
)
declare -A MODULE_ABOUT=(
  [dj]="Decks, crossfader and the library (a background librarian analyses your music)"
  [ai_dj]="The DJ Booth with the AI DJ and stem controls (brings DJ)"
  [visualiser]="Visuals to the music, for a screen or a projector"
  [podcast]="Mic processing, recording and streaming (Icecast, RTMP, a file)"
  [live_coding]="Tidal, Pattern and the Sequencer"
  [plugins]="Native VST3 plugins on the master, a channel, AUX or FX"
  [controllers]="MIDI and HID controllers (a udev rule for raw HID; asks for sudo)"
  [themes]="Patch Light and Patch Dark in Omarchy's theme menu"
)
# Layouts: id, name, what it opens, the modules it needs.
LAYOUT_IDS=(simple basic-dj ai-dj performance-dj dj-studio podcast live-code pro)
declare -A LAYOUT_NAME=(
  [simple]="Simple" [basic-dj]="Basic DJ" [ai-dj]="AI DJ" [performance-dj]="Performance DJ" [dj-studio]="DJ Studio"
  [podcast]="Podcast" [live-code]="Live Code" [pro]="Pro"
)
declare -A LAYOUT_ABOUT=(
  [simple]="Mixer, Router, Player · 1 workspace"
  [basic-dj]="Decks, crossfader, library · 1 workspace"
  [ai-dj]="DJ Booth with the AI DJ, library, meter · 1 workspace"
  [performance-dj]="Booth · control · Visualiser · 3 workspaces"
  [dj-studio]="Booth · mixing desk (Router, EQ, Mixer) · library · 3 workspaces"
  [podcast]="Mic, Mixer, meter, Player, Recorder, Broadcast · 1 workspace"
  [live-code]="Tidal, meter, Mixer · Visualiser · 2 workspaces"
  [pro]="EQ, meter, Mixer · Router, Analyzer, Recorder, plugins · 2 workspaces"
)
declare -A LAYOUT_NEEDS=(
  [simple]="" [basic-dj]="dj" [ai-dj]="dj ai_dj" [performance-dj]="dj ai_dj visualiser" [dj-studio]="dj ai_dj visualiser"
  [podcast]="podcast" [live-code]="live_coding visualiser" [pro]=""
)
CHOSEN=""   # the modules (and themes) on
has() { [[ " $CHOSEN " == *" $1 "* ]]; }
offered() {
  local m
  for m in ${LAYOUT_NEEDS[$1]}; do has "$m" || return 1; done
}
# The layout that suits the modules best, when none is chosen.
best_layout() {
  local l
  for l in performance-dj ai-dj basic-dj podcast live-code simple; do
    offered "$l" && { echo "$l"; return; }
  done
}
profile_modules() {
  case "$1" in
    full) echo "${MODULE_IDS[*]}" ;;
    minimal) echo "" ;;
    # The older profiles.
    dj) echo "dj ai_dj visualiser" ;;
    mixer) echo "visualiser podcast live_coding plugins controllers themes" ;;
    *) return 1 ;;
  esac
}

logo() {
  cat <<'LOGO'
█▀█ ▄▀█ ▀█▀ █▀▀ █ █
█▀▀ █▀█  █  █▄▄ █▀█
LOGO
}

setup_screen() {
  clear
  gum style --border rounded --border-foreground 1 --padding "1 4" --margin "1 2" \
    "$(gum style --foreground 1 --bold "$(logo)")" "" \
    "$(gum style --bold "The Omarchy audio environment")" \
    "$(gum style --faint "v$VERSION · routing, mixing, metering, recording, DJ")"
  local pick
  pick=$(gum choose --header "  How do you want to install Patch?" --cursor "  › " --height 6 \
    "Minimal   The core: Patch replaces Omarchy's audio (volume, outputs, bar menu, Mixer, Router, Player)" \
    "Full      The core and every module: DJ, AI DJ, Visualiser, podcast, live coding, plugins, controllers" \
    "Custom    The core, and the modules you choose") || exit 1
  case "$pick" in
    Minimal*) PROFILE=minimal ;;
    Full*) PROFILE=full ;;
    Custom*)
      local items=() id line out
      for id in "${MODULE_IDS[@]}"; do
        items+=("$(printf '%-20s %s' "${MODULE_NAME[$id]}" "${MODULE_ABOUT[$id]}")")
      done
      out=$(gum choose --no-limit --height 12 \
        --header "  The core is always in. Choose the modules (x toggles, enter confirms)" \
        --cursor "  › " "${items[@]}") || exit 1
      CHOSEN=""
      for id in "${MODULE_IDS[@]}"; do
        if grep -q "^${MODULE_NAME[$id]} " <<<"$out"; then CHOSEN+="$id "; fi
      done
      PROFILE=custom
      ;;
  esac
}

layout_screen() {
  local items=() l line out first
  first=$(best_layout)
  items+=("$(printf '%-16s %s' "${LAYOUT_NAME[$first]}" "${LAYOUT_ABOUT[$first]}")")
  for l in "${LAYOUT_IDS[@]}"; do
    [[ $l == "$first" ]] && continue
    offered "$l" && items+=("$(printf '%-16s %s' "${LAYOUT_NAME[$l]}" "${LAYOUT_ABOUT[$l]}")")
  done
  out=$(gum choose --height 10 --cursor "  › " \
    --header "  Your default layout: what the Patch launcher opens (nothing opens at login)" \
    "${items[@]}") || exit 1
  for l in "${LAYOUT_IDS[@]}"; do
    if [[ $out == "${LAYOUT_NAME[$l]} "* ]]; then LAYOUT=$l; fi
  done
}

# Without a terminal (or gum): the profile or modules given, else Full.
# Every choice replaces Omarchy's audio.
INTERACTIVE=0
[[ -t 0 && -t 1 ]] && command -v gum >/dev/null && INTERACTIVE=1
if [[ -z $PROFILE ]]; then
  if ((INTERACTIVE)); then setup_screen; else PROFILE=full; fi
fi
if [[ $PROFILE == custom && -n $MODULES_ARG ]]; then
  CHOSEN=""
  for id in ${MODULES_ARG//,/ }; do
    [[ -n ${MODULE_NAME[$id]:-} ]] || { echo "modules: ${MODULE_IDS[*]}" >&2; exit 2; }
    CHOSEN+="$id "
  done
elif [[ $PROFILE != custom ]]; then
  CHOSEN=$(profile_modules "$PROFILE") || { echo "profiles: full minimal (or --modules …)" >&2; exit 2; }
fi
# The AI DJ plays on the decks.
has ai_dj && ! has dj && CHOSEN+="dj "
if [[ -z $LAYOUT ]]; then
  if ((INTERACTIVE)); then layout_screen; else LAYOUT=$(best_layout); fi
fi
[[ -n ${LAYOUT_NAME[$LAYOUT]:-} ]] || { echo "layouts: ${LAYOUT_IDS[*]}" >&2; exit 2; }
offered "$LAYOUT" || { echo "the $LAYOUT layout needs: ${LAYOUT_NEEDS[$LAYOUT]}" >&2; exit 2; }
# The stem separator is several GB: asked for, with the AI DJ.
if has ai_dj && ((STEMS)) && ((INTERACTIVE)); then
  gum confirm "Download the stem separator now? (several GB; AI DJ stem controls. Later: Ctrl+K, Setup)" || STEMS=0
fi
SETUP=()
for id in "${CORE[@]}"; do SETUP+=("$id=on"); done
for id in "${MODULE_IDS[@]}"; do
  if has "$id"; then SETUP+=("$id=on"); else SETUP+=("$id=off"); fi
done
SETUP+=("${OVERRIDES[@]}" "layout=$LAYOUT")
say "Setup: ${PROFILE} · modules: ${CHOSEN:-none (the core)} · default layout: $LAYOUT"

# 1 · The binary. A release kit (the download for your machine) carries
# it in bin/; a checkout of a release tag fetches the kit's binary; any
# other checkout (work in progress) is compiled here.
PREBUILT=""
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
release_checkout() {
  if ! git rev-parse --git-dir >/dev/null 2>&1; then return 0; fi
  [[ $(git describe --exact-match --tags HEAD 2>/dev/null) == "v$VERSION" ]] && git diff --quiet HEAD 2>/dev/null
}
fetch_prebuilt() {
  local kit="patch-$VERSION-linux-$ARCH.tar.gz"
  local url="https://github.com/$REPO/releases/download/v$VERSION"
  say "Fetching the ready-made Patch $VERSION for $ARCH"
  if ! { curl -fsSL -o "$TMP/$kit" "$url/$kit" && curl -fsSL -o "$TMP/$kit.sha256" "$url/$kit.sha256"; } 2>/dev/null; then
    # A private repository: through the GitHub CLI when it's signed in.
    command -v gh >/dev/null && gh auth status >/dev/null 2>&1 \
      && gh release download "v$VERSION" -R "$REPO" -D "$TMP" -p "$kit" -p "$kit.sha256" --clobber >/dev/null 2>&1 \
      || return 1
  fi
  (cd "$TMP" && sha256sum -c --quiet "$kit.sha256") || { echo "The download doesn't match its checksum" >&2; return 1; }
  tar -xzf "$TMP/$kit" -C "$TMP" "patch-$VERSION/bin/omarchy-patch" && PREBUILT="$TMP/patch-$VERSION/bin/omarchy-patch"
}
if [[ $BUILD_HERE == 0 ]]; then
  if [[ -x bin/omarchy-patch ]]; then
    PREBUILT=bin/omarchy-patch
  elif release_checkout; then
    fetch_prebuilt || echo "No ready-made build for $ARCH: compiling Patch here instead (a few minutes)" >&2
  fi
fi

# 2 · Packages. Runtime: PipeWire and its tools, FFmpeg (decoding and
# analysis), Rubber Band (keylock), SQLite (the library), fontconfig,
# notifications, real-time scheduling for the audio thread (rtkit and
# the realtime group). To compile: Rust, pkg-config, a C compiler.
RUNTIME=(pipewire libpulse wireplumber ffmpeg rubberband sqlite fontconfig libnotify xdg-user-dirs rtkit realtime-privileges uv python)
BUILD=(rust pkgconf gcc)
OPTIONAL=(wl-clipboard)
install_packages() {
  [[ $DEPS == 1 ]] || return 0
  if command -v pacman >/dev/null; then
    missing=()
    for p in "$@"; do
      pacman -Qq "$p" >/dev/null 2>&1 || missing+=("$p")
    done
    # rustup provides cargo too: don't ask for the rust package then.
    if command -v cargo >/dev/null; then
      missing=("${missing[@]/rust}")
    fi
    missing=($(printf '%s\n' "${missing[@]}" | sed '/^$/d'))
    if ((${#missing[@]})); then
      say "Installing packages: ${missing[*]}"
      sudo pacman -S --needed --noconfirm "${missing[@]}"
    fi
  else
    echo "No pacman: install these yourself if missing: $*" >&2
  fi
}
install_packages "${RUNTIME[@]}" "${OPTIONAL[@]}"
# The ready-made binary has to run against this system's libraries.
if [[ -n $PREBUILT ]] && ! "$PREBUILT" --version >/dev/null 2>&1; then
  echo "The ready-made build doesn't run on this system: compiling Patch here instead" >&2
  PREBUILT=""
fi
[[ -z $PREBUILT && -f Cargo.toml ]] && install_packages "${BUILD[@]}"
# Real time: without it the engine's audio thread can be pre-empted and
# the sound drops out under load. The realtime group's limits apply from
# the next login.
RELOGIN=0
if getent group realtime >/dev/null && ! id -nG "$USER" | tr ' ' '\n' | grep -qx realtime; then
  say "Adding $USER to the realtime group (real-time audio)"
  if sudo usermod -aG realtime "$USER"; then RELOGIN=1; else echo "Could not add you to 'realtime': sudo usermod -aG realtime $USER" >&2; fi
fi

# Raw HID: a controller speaking a vendor protocol has no evdev node in the
# seat, so logind's uaccess tag never reaches its /dev/hidraw node and the
# controller service cannot open it. The rule grants the active seat access.
RULES=/etc/udev/rules.d/70-omarchy-patch-controllers.rules
if has controllers && [[ ! -f $RULES ]]; then
  say "Granting raw-HID access for controllers (udev rule)"
  if sudo install -Dm644 packaging/70-omarchy-patch-controllers.rules "$RULES" \
     && sudo udevadm control --reload \
     && sudo udevadm trigger --subsystem-match=hidraw; then
    :
  else
    echo "Could not install $RULES: controllers that use a raw HID protocol will list but not open." >&2
  fi
fi

# 3 · Compile, when there's no ready-made build.
if [[ -z $PREBUILT && ! -f Cargo.toml ]]; then
  echo "This kit holds only the compiled Patch, and it can't run here (or --build was given)." >&2
  echo "Install from the source instead: https://github.com/$REPO" >&2
  exit 1
fi
if [[ -z $PREBUILT ]]; then
  command -v cargo >/dev/null || { echo "cargo not found: install rust (or rustup) first" >&2; exit 1; }
  say "Compiling Patch (release; a few minutes the first time)…"
  cargo build --release --locked
  PREBUILT=target/release/omarchy-patch
fi

# 4 · Install: the binary, the desktop entries (their Exec uses the name,
# found on PATH).
say "Installing into $PREFIX"
install -Dm755 "$PREBUILT" "$BIN/omarchy-patch"
# Installed over a running Patch: the engine hands over to this build now,
# without a gap (otherwise the old one plays on until the next login).
# Then the librarian stops: the new engine starts the new one on its next
# pass (within 30 s), in the session's environment; it analyses in the
# background and picks up where it stopped. After a failed handover (from
# SSH, without the session) both stay as they are. The patterns match only
# those processes' own command lines.
if pgrep -u "$(id -u)" -f -x '.*omarchy-patch engine' >/dev/null; then
  say "Handing the running engine over to this version"
  if "$BIN/omarchy-patch" engine upgrade >/dev/null; then
    pkill -u "$(id -u)" -f -x '.*omarchy-patch librarian' || true
  else
    echo "The running engine didn't hand over: the new one starts at your next login" >&2
  fi
fi
# And the windows: closed now (the audio plays on), reopened at the end as
# they were, the layout or the windows that were open. Only in the desktop
# session itself: from SSH or a TTY they can't reopen, so they stay.
REOPEN=""
if [[ -n ${WAYLAND_DISPLAY:-} ]]; then
  windows=$("$BIN/omarchy-patch" status 2>/dev/null) || windows=""
  if [[ $windows == ok* ]]; then
    # `ok open=mixer,meters layout=simple edited=0`; no layout is `-`.
    layout=$(sed -n 's/.* layout=\([^ ]*\).*/\1/p' <<<"$windows")
    open=$(sed -n 's/.*open=\([^ ]*\).*/\1/p' <<<"$windows")
    if [[ -n $layout && $layout != - ]]; then
      REOPEN="layout $layout"
    elif [[ -n $open ]]; then
      REOPEN="open ${open//,/ }"
    fi
    say "Closing Patch's windows: they reopen with this version at the end"
    "$BIN/omarchy-patch" quit >/dev/null 2>&1 || true
    for _ in $(seq 40); do
      [[ $("$BIN/omarchy-patch" status 2>/dev/null) == closed ]] && break
      sleep 0.25
    done
  fi
fi
mkdir -p "$APPS"
install -m644 integration/desktop/*.desktop "$APPS/"
command -v update-desktop-database >/dev/null && update-desktop-database "$APPS" >/dev/null 2>&1 || true
case ":$PATH:" in
  *":$BIN:"*) ;;
  *) echo "Note: $BIN is not on your PATH; add it to use omarchy-patch from a terminal." >&2 ;;
esac

# The themes ship with Patch (setup links them into Omarchy's theme menu).
mkdir -p "$SHARE/stems"
install -m644 tools/stems/setup.py tools/stems/demucs_adapter.py "$SHARE/stems/"
mkdir -p "$SHARE/themes"
rm -rf "$SHARE/themes/patch-light" "$SHARE/themes/patch-dark"
cp -r themes/patch-light themes/patch-dark "$SHARE/themes/"

# This machine, measured once (under a second): the fastest DSP kernels
# for its CPU, and the drawing tier its windows start at.
say "Measuring this machine (audio kernels, drawing)"
"$BIN/omarchy-patch" optimize --quick >/dev/null 2>&1 || true

# 5 · The setup: system audio, DJ Booth, service, bar menu, themes.
say "Applying your setup"
# The bar's main output starts at Patch itself: the full Mixer console.
# A reinstall keeps the choice made since.
MAIN_OUTPUT="${XDG_CONFIG_HOME:-$HOME/.config}/omarchy-patch/main-output"
[[ -s $MAIN_OUTPUT ]] || { mkdir -p "${MAIN_OUTPUT%/*}" && echo patch > "$MAIN_OUTPUT"; }
"$BIN/omarchy-patch" setup set --all "${SETUP[@]}"

if has ai_dj && ((STEMS)); then
  say "Installing the stem separator for the AI DJ (stem audio remains on demand)"
  "$BIN/omarchy-patch" setup stems install || echo "The stem separator didn't install: Ctrl+K, Setup, Stem separator tries again" >&2
fi

# 6 · The phone remote (with the DJ): the Booth, Mixer and library in a
# phone's browser, over Tailscale only (https://<this machine>.ts.net:8124,
# for your own Tailscale account). It runs once this machine is on
# Tailscale; without it the remote is installed but stays off.
if has dj && ((REMOTE)) && [[ -x bin/patch-remote || -x target/release/patch-remote ]]; then
  say "Installing the phone remote"
  remote_bin=bin/patch-remote
  [[ -x $remote_bin ]] || remote_bin=target/release/patch-remote
  install -Dm755 "$remote_bin" "$BIN/patch-remote"
  install -Dm755 remote/patch-remote-launch "$SHARE/patch-remote-launch"
  UNITS="${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user"
  mkdir -p "$UNITS"
  install -m644 remote/patch-remote.service remote/patch-remote-follow.path \
    remote/patch-remote-follow.service "$UNITS/"
  REMOTE_ENV="${XDG_CONFIG_HOME:-$HOME/.config}/patch-remote/environment"
  # This machine's Tailscale name and account: the only origin and the
  # only login the remote accepts.
  tailnet=$(tailscale status --json 2>/dev/null | python3 -c '
import json, sys
d = json.load(sys.stdin); s = d["Self"]
print(s["DNSName"].rstrip("."), d["User"][str(s["UserID"])]["LoginName"])' 2>/dev/null) || tailnet=""
  if [[ ! -s $REMOTE_ENV && -n $tailnet ]]; then
    mkdir -p "${REMOTE_ENV%/*}" && chmod 700 "${REMOTE_ENV%/*}"
    printf 'PATCH_REMOTE_ORIGIN="https://%s:8124"\nPATCH_REMOTE_USER="%s"\n' $tailnet > "$REMOTE_ENV"
  fi
  if [[ -s $REMOTE_ENV ]]; then
    # Tailscale Serve carries the phone's HTTPS to the remote on
    # 127.0.0.1:8124; a route already on that port is left alone.
    if ! tailscale serve status --json 2>/dev/null | grep -q '"8124"'; then
      tailscale serve --bg --https=8124 http://127.0.0.1:8124 >/dev/null 2>&1 \
        || sudo tailscale serve --bg --https=8124 http://127.0.0.1:8124 >/dev/null \
        || echo "Tailscale Serve didn't take port 8124 (HTTPS certificates on in the Tailscale admin?): tailscale serve --bg --https=8124 http://127.0.0.1:8124" >&2
    fi
    systemctl --user daemon-reload
    systemctl --user enable patch-remote.service patch-remote-follow.path >/dev/null 2>&1
    systemctl --user restart patch-remote.service patch-remote-follow.path
    say "Phone remote: $(sed -n 's/^PATCH_REMOTE_ORIGIN="\(.*\)"/\1/p' "$REMOTE_ENV")/ (on Tailscale, your account)"
  else
    systemctl --user daemon-reload
    echo "Phone remote installed, off: sign this machine in to Tailscale (tailscale up), then run ./install.sh again" >&2
  fi
fi

if [[ $RELOGIN == 1 ]]; then
  say "Log out and in once: real-time audio starts with your next session"
fi
if [[ -n $REOPEN ]]; then
  say "Reopening Patch's windows ($REOPEN)"
  # shellcheck disable=SC2086 # the surfaces are separate words
  setsid -f "$BIN/omarchy-patch" $REOPEN </dev/null >/dev/null 2>&1 || true
fi
say "Done"
"$BIN/omarchy-patch" welcome
true
