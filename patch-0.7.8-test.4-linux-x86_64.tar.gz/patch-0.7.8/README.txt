Patch 0.7.8 (test.4), a test build for Omarchy (Arch Linux, Hyprland), x86_64.

  ./install.sh       choose Minimal, Full or Custom, and your default layout
  ./uninstall.sh     puts Omarchy's own audio back

With the DJ, the phone remote comes along: on Tailscale it is at
https://<this machine>.ts.net:8124 for your own Tailscale account.

After installing, press Ctrl+K in any Patch window for the controller;
omarchy-patch welcome shows the short guide again.
