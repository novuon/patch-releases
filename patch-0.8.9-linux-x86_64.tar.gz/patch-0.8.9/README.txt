Patch 0.8.9 for Omarchy (Arch Linux, Hyprland), x86_64.

  ./install.sh       choose how you use Patch (Standard, DJ, Podcast, Live
                     coding, Everything or Custom), its modules and your layout
  ./uninstall.sh     puts Omarchy's own audio back

With the DJ, the phone remote comes along: on Tailscale it is at
https://<this machine>.ts.net:8124 for your own Tailscale account.

After installing, press Ctrl+K in any Patch window for the controller;
omarchy-patch welcome shows the short guide again.
