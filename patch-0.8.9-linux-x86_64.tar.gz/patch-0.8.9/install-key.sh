# Sourced by install.sh: the key for a module that needs one (modules.json
# `licences`), asked once while installing; Enter leaves it for later
# (Settings, or `omarchy-patch licence activate <key>`). Sets KEY.
key_prompt() {
  local lname lyear lweek pyear pweek lsoon lnotify
  IFS='|' read -r lname lyear lweek pyear pweek lsoon lnotify < <(python3 - "$CAT" <<'PY'
import json, sys
l = json.load(open(sys.argv[1]))["licences"][0]
pr = l.get("prices", {})
print(f'{l["name"]}|{l["buy_url"]}|{l.get("trial_url", "")}|{pr.get("year", "")}|{pr.get("week", "")}|{"soon" if l.get("coming_soon") else ""}|{l.get("notify_url", "")}')
PY
)
  # Without gum (outside Omarchy): the same lines, plain.
  if ! command -v gum >/dev/null; then
    if [[ $lsoon == soon ]]; then
      printf '\n  %s is coming soon\n  %s · %s\n  Tell me when it is available: %s\n  Have a key already? Paste it. No key: Enter.\n' \
        "$lname" "$pyear" "$pweek" "$lnotify"
    else
      printf '\n  %s needs a key\n  A year · %s: %s\n  Try it first · %s: %s\n  Already subscribed? Paste the key (Access purchase in Polar'"'"'s email). No key yet: Enter, and add it later in Settings.\n' \
        "$lname" "$pyear" "$lyear" "$pweek" "$lweek"
    fi
    read -rp "  Key (Enter: later): " KEY || KEY=""
    return 0
  fi
  if [[ $lsoon == soon ]]; then
  gum style --margin "1 2" \
    "$(gum style --bold "$lname is coming soon")" \
    "$(gum style --faint "$pyear · $pweek")" \
    "Tell me when it's available: $lnotify" \
    "$(gum style --faint "Have a key already? Paste it. No key: Enter.")"
  else
  gum style --margin "1 2" \
    "$(gum style --bold "$lname needs a key")" \
    "A year · $pyear: $lyear" \
    "Try it first · $pweek: $lweek" \
    "$(gum style --faint "Already subscribed? Paste the key (Access purchase in Polar's email). No key yet: Enter, and add it later in Settings.")"
  fi
  KEY=$(gum input --placeholder "PATCH-…  (Enter: later)" --width 60) || KEY=""
}
